package tests;

import mainPackage.SomeClass;
import org.junit.Test;

import static org.junit.Assert.assertTrue;

public class TestWithDifferentClasspath {

   @Test
   public void unitTest() {
      SomeClass s = new SomeClass("Lala", "lulu");
      s.recursiveCall(s.someString);
   }
}
