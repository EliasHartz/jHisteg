package mainPackage.helloWorld;

public class HelloWorldMain {

	protected String whatToSay;
	protected boolean capital = true;
	
	public static void main(String[] args) {
		String out = "";
		for (String s : args) out+=s;
		System.out.println("Parent Class: "+out);
	}

	/**
	 * Creates a new object.
	 */
	public HelloWorldMain(){
		this("Hello world");
	}
	
	/**
	 * Creates a new object with data.
	 * 
	 * @param whatToSay : what is printed
	 */
	public HelloWorldMain(String whatToSay){
		this.whatToSay = whatToSay;
	}
	
	/**
	 * Says something out aloud.
	 */
	public void say(){
		String s = whatToSay;
		if (capital)
			s = whatToSay.toUpperCase();
		System.out.println(s);
	}
	
	/**
	 * Updates what to say.
	 * 
	 * @param newData : what to say from now on
	 */
	public void setWhatToSay(String newData){
		if (newData.equals(whatToSay)) return;
		whatToSay = newData;
	}

	/**
	 * Greet someone.
	 * 
	 * @param name : name of the person
	 */
	public void respond(String name){
		if (capital)
			System.out.println("HELLO, "+name.toUpperCase());
		else
			System.out.println("Hello, "+name);
	}
}
