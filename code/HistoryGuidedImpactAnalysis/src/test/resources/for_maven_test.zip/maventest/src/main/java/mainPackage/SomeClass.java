package mainPackage;

public class SomeClass {

   public final String someString;
   
   public SomeClass(String s1, String s2){
      someString = s1 + s2;
   }
   
   public void recursiveCall(String s) {
      if (s.isEmpty()){
         System.out.println("DONE");
	 return;
       }
      else {
         recursiveCall(s.substring(1));
      }
   }
}
