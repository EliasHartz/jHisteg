package tests;

import static org.junit.Assert.*;

import org.junit.Test;
import static org.junit.Assert.*;
import otherPackage.IhateTheWorld;
import mainPackage.helloWorld.HelloWorldMain;

public class TestSuite2 {

   @Test
   public void testSomething() {
      HelloWorldMain h = new HelloWorldMain();
      h.respond("Elias");
      assertEquals("A","A");
   }

   @Test
   public void testSomethingElse() {
      IhateTheWorld a = new IhateTheWorld();
      a.say();
      assertTrue(true);
   }

}
