package otherPackage;

import mainPackage.helloWorld.HelloWorldMain;

public class IhateTheWorld extends HelloWorldMain{
	   
	public static void main(String[] args) {
		String out = "";
		for (String s : args) out+=s;
		System.out.println("Child Class: "+out);
	}

	public IhateTheWorld(){
		super("I hate the world");
		capital = false;
	}
	
	public void say(){
	if (!whatToSay.equals("I hate the world"))
		System.out.println("I really really hate the world");
	else super.say();
	}
	
	public void setWhatToSay(String newData){
		/* nothing in fact, cannot be set */
	}

}
